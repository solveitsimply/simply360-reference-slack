# @simply360/blueprint-sdk

Typed, client-side SDK for authoring **Simply360 External Blueprint packages** in
the closed structural / draft-safe subset (Ratified Directions 16, 17, 25).

The SDK is a thin layer over the public
[`@s360/contracts/app-platform`](../contracts) contracts. It contains **no
internal database models, numeric internal identifiers, secrets, or
authorization logic**. The Simply360 platform remains the sole runtime authority
for previewing, installing, upgrading, and uninstalling Blueprint packages.

> Status: `0.x` prerelease groundwork. Not published. Apache-2.0 (see `LICENSE`
> and `NOTICE`).

## Distribution boundary

The npm tarball is self-contained for Simply360-owned code: build output embeds
the exact `@s360/contracts/app-platform` implementation and declaration surface
from this monorepo. Consumers never install or resolve the internal
`@s360/contracts` package. This is a distribution decision, not a second
contract authority; SDK source continues to import and reuse the canonical
app-platform implementation verbatim.

## What it provides

- **Typed builders** for the closed subset: closed-schema Collections and
  fields, safe formula AST nodes, bounded Smart Collections, internal-only Data
  Views and reports, labels, shared collection contracts, mappings, options, and
  explicit lifecycle declarations.
- **Validation** with precise, machine-readable `{ path, message, code }` issues,
  including a strict I-JSON text entry point.
- **Canonicalization** (RFC 8785 JCS) and **content hashing** (SHA-256), reused
  verbatim from the app-platform foundation — never reimplemented here.
- **Package/content-hash helpers** that assemble a signed-package envelope whose
  declared `definitionSha256` provably binds the exact canonical definition
  bytes.
- **Deterministic JSON Schema emission** for the external package format,
  projected directly from the reused Zod sources.

## Example

```ts
import {
  defineExternalBlueprint,
  defineCollection,
  defineField,
  defineLifecycleDeclaration,
  formulaField,
  validateExternalBlueprintDefinition,
  buildExternalBlueprintPackage,
} from '@simply360/blueprint-sdk';

const definition = defineExternalBlueprint({
  collections: [
    defineCollection({
      collectionKey: 'contact',
      label: { en: 'Contact' },
      lifecycleOwner: 'INTEGRATION',
      recordLifecycle: 'ARCHIVE_SUPPORTED',
      calculatedName: formulaField('full-name'),
      fields: [
        defineField({ fieldKey: 'full-name', label: { en: 'Full name' }, required: true, kind: 'TEXT', maxLength: 200 }),
      ],
      sharedContractKeys: [],
    }),
  ],
  smartCollections: [],
  dataViews: [],
  reports: [],
  labels: [],
  sharedCollectionContracts: [],
  mappings: [],
  options: [],
  lifecycle: [
    defineLifecycleDeclaration({ resourceType: 'COLLECTION', collectionKey: 'contact', owner: 'INTEGRATION', uninstallBehavior: 'PROMPT_SOFT_DELETE' }),
  ],
});

const result = validateExternalBlueprintDefinition(definition);
if (!result.valid) throw new Error(JSON.stringify(result.issues, null, 2));

const pkg = await buildExternalBlueprintPackage(definition, {
  publisherSlug: 'acme-crm',
  packageKey: 'crm-starter',
  semanticVersion: '1.0.0',
  displayName: 'CRM Starter',
  summary: 'A safe structural CRM starter package.',
  support: { supportUrl: 'https://acme.example/support', escalationEmail: 'support@acme.example' },
  compatibility: { minimumPlatformVersion: '1.0.0' },
  provenance: {
    sourceRepository: 'https://github.com/acme/crm-starter',
    sourceCommit: '0123456789abcdef0123456789abcdef01234567',
  },
});
```

## Peer dependency

Supply `zod` (`^4.3.6`) — it is the SDK's only runtime peer and is not bundled.
