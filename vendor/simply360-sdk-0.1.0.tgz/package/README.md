# @simply360/sdk

Typed TypeScript client for the [Simply360](https://simply360.app) public API.

```bash
npm install @simply360/sdk
```

```ts
import { Simply360 } from '@simply360/sdk';

const s360 = new Simply360({
  apiKey: process.env.S360_API_KEY!, // s360_live_...
});
const collections = await s360.dataCollections.list();
```

## Ask Simply streaming

Ask Simply is a first-party, user-owned surface. Configure a signed-in user
token and Team context; API keys and external OAuth clients cannot open its run
stream. A running send can expose safe provisional answer chunks before the
canonical assistant message is persisted.

```ts
const askSimply = new Simply360({
  getToken: async () => process.env.S360_USER_ACCESS_TOKEN!,
  teamSimplyId: 'TEAM-0001-0001',
});
const reply = await askSimply.teamAgent.sendMessage({
  message: 'Summarize the active records in this view.',
  idempotencyKey: crypto.randomUUID(),
});

if (reply.data.status === 'RUNNING') {
  const seenEventIds = new Set<string>();
  let after: string | undefined;
  let provisional = '';
  let terminal = false;

  for (let connection = 0; connection < 2 && !terminal; connection += 1) {
    try {
      for await (const event of askSimply.teamAgent.streamRun(reply.data.runSimplyId, {
        after,
        seenEventIds,
      })) {
        if (event.type === 'activity' || event.type === 'assistant.delta' || event.type === 'assistant.reset' || event.type === 'final') {
          after = event.id;
        }
        if (event.type === 'assistant.delta') provisional += event.text;
        if (event.type === 'assistant.reset') provisional = '';
        if (event.type === 'final') {
          console.log(event.assistantMessage.content);
          terminal = true;
          break;
        }
        if (event.type === 'error' && !event.retryable) {
          terminal = true;
          break;
        }
      }
    } catch {
      // The second connection resumes after the last durable cursor.
    }
  }

  // The JSON run read remains authoritative after final, reconnect, or a
  // bounded fallback from an unavailable/malformed stream.
  const canonical = await askSimply.teamAgent.getRun(reply.data.runSimplyId);
  console.log(canonical.data.assistantMessage?.content);
}
```

Reuse the same `seenEventIds` set and pass the last durable event ID as `after`
when reconnecting. `assistant.delta` text is provisional; discard only the
candidate named by `assistant.reset`. Hosted MCP intentionally has no equivalent
Ask Simply stream because it does not have this first-party user/session identity.

## Simply Bookings

Authenticated Simply Bookings authoring uses the typed `scheduling` client and public
Simply IDs throughout. Team context is required for reads and draft creation.

```ts
const scheduling = new Simply360({
  getToken: async () => process.env.S360_USER_ACCESS_TOKEN!,
  teamSimplyId: 'TEAM-0001-0001',
});

const { data: eventTypes } = await scheduling.scheduling.listEventTypes({ limit: 25, offset: 0 });
await scheduling.scheduling.createEventType({
  ownerSchedulingHostProfileSimplyId: 'HOST-0001-0001',
  name: { en: 'Consultation' },
  slug: 'consultation',
  timezone: 'America/Los_Angeles',
  durationMinutes: 30,
  locationPolicy: { kind: 'CUSTOM', publicLabel: 'Front desk' },
});

await scheduling.scheduling.patchEventType('EVNT-0001-0001', {
  durationMinutes: 45,
});

const publication = await scheduling.scheduling.publishEventType('EVNT-0001-0001', {
  idempotencyKey: '0ed8a029-3644-4726-9a0f-fd2901844111',
  bookingOutcomeCollectionSimplyId: 'BOOK-0001-0001',
  secretPolicy: 'CREDENTIAL_REQUIRED',
});

// Persist this value immediately when non-null. It is returned only by the
// initial successful credential-required publication; idempotent retries and
// unpublish responses intentionally return `bookingCredential: null`.
const credential = publication.data.bookingCredential;
```

Draft updates are strict and nonempty. Team, owner, visibility, and lifecycle
fields are immutable through PATCH. A booking channel is server-owned and is
created only by the governed publication operation; it remains available as a
public Simply ID in responses and publication projections.

## Document generation

Document generation uses public Simply IDs throughout. The submitted record
array is the authoritative output order; use `copiesPerRecord` rather than
duplicating a record ID. Creation is person-owned and requires a signed-in Team
Admin or Team User token plus selected Team context. Team API keys are not
supported for document-generation creation.

```ts
const userS360 = new Simply360({
  getToken: async () => process.env.S360_USER_ACCESS_TOKEN!,
  teamSimplyId: 'TEAM-0001-0001',
});

await userS360.backgroundTasks.createDocumentGeneration({
  generationMode: 'template',
  templateSimplyId: 'CTPL-0001-0001',
  dataCollectionSimplyId: 'DCOL-0001-0001',
  dataRecordSimplyIds: ['DREC-0001-0002', 'DREC-0001-0001'],
  outputMode: 'imposed',
  imposition: { startCell: 6, copiesPerRecord: 2, cutGuides: true },
});
```

Alignment test sheets use `renderPurpose: 'test-sheet'`, accept no records or
write-back destinations, and are unmetered. Finished exact-media results,
including document runs with partial-success write-back, may include the safe
optional `result.formatSummary`; storage keys and signed URLs are never part of
task detail responses.

## Documentation

- Getting started, authentication, and full guides: [developers.simply360.app](https://developers.simply360.app)
- API reference (OpenAPI): [developers.simply360.app/api-reference](https://developers.simply360.app/api-reference)

## Support

Questions or issues: [developers.simply360.app/feedback](https://developers.simply360.app/feedback)
