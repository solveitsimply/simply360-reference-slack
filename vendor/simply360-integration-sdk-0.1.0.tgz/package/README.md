# @simply360/integration-sdk

Thin, first-party client and validator layer for building external Simply360
marketplace apps. It re-exports the public app-platform contracts from
[`@s360/contracts/app-platform`](../contracts) and adds ergonomic helpers on top
of them.

> Status: `0.x`, unpublished groundwork slice of MKT-05. The SDK is
> behavior-dark — importing it grants no runtime authority. Durable event
> ledger/outbox, the delivery worker, hardened egress transport, and CLI
> extensions land in later MKT-05 slices.

## Distribution boundary

The packed SDK includes the Simply360 contract implementation and needs only
its public Zod peer at runtime. Each module entry point supports ESM and
CommonJS with matching TypeScript declarations. The packed-consumer check
resolves every declared module export in both formats, including
`remote-operations`, and rejects missing export targets and imports of the
private `@s360` scope.

## What is in this slice

- **Webhook v2** (`@simply360/integration-sdk/webhooks`): byte-exact signing
  input (`S360-HMAC-V2` + LF-joined fields + lowercase-hex SHA-256 of the raw
  body), the strict `X-S360-Signature` `v2;…` header grammar, a receiver
  verifier (timing-safe HMAC comparison, current-or-overlapping-previous key
  acceptance, a configurable ±300s replay window, identity-header cross-checks),
  a sender-side signing helper for the future delivery worker and for fixtures,
  attempt-aware `(eventId, deliveryId)` dedupe helpers, idempotency-key helpers,
  and a frozen golden-vector fixture set the server-side signer must match.
- **Events** (`@simply360/integration-sdk/events`): re-exported occurrence
  envelope and payload schemas plus typed event-narrowing helpers.
- **Manifest** (`@simply360/integration-sdk/manifest`): re-exported app-manifest
  types, schema, and normalizer.
- **OAuth** (`@simply360/integration-sdk/oauth`): PKCE S256 verifier/challenge
  generation, `state` helpers, and token-response parsing types. No HTTP client
  dependency beyond an injectable `fetch`. User-delegated token responses retain
  a validated `authorization_binding` identity projection with the exact public
  Team, installation, member, client, epoch, consent and grant coordinates.
  Persist each token family under those coordinates; a second installation or
  grant must never overwrite the first. This receipt is metadata, not current
  authorization: the server checks live authority on every request. Provider
  account links remain separate resources from these Simply360 OAuth grants.
- **Fixtures** (`@simply360/integration-sdk/fixtures`): deterministic install
  and event fixtures for downstream test suites.
- **Primary file provider** (`@simply360/integration-sdk/file-provider`): the
  closed v1 request/response envelopes and operation bodies, exact route table,
  strict canonical-envelope parsing, RFC 8785 signing bytes, portable Ed25519
  signing/verification ports, Web Crypto adapters, and pinned golden vectors.
  The package also ships the canonical public manifest and vectors at
  `@simply360/integration-sdk/file-provider/contract.json` and
  `@simply360/integration-sdk/file-provider/vectors.json`.
- **Conference connector contract** (`@simply360/integration-sdk/conformance`):
  `verifyAndParseConferenceRemoteActionRequest` verifies the Marketplace
  remote-action envelope (expiry, input hash, key identity, and P-256 DER
  signature) before deriving conference context or parsing the strict
  provider-neutral command. The command contains only opaque Simply IDs,
  booking/resource references, and time range/topic; connector outcomes return
  only a guest-safe join projection. The contract never carries provider IDs,
  payloads, PII, secrets, or host start URLs. The raw structural parser is
  intentionally private so callers cannot accidentally treat an unsigned
  envelope as verified authority.

  `runConferenceConformance` is the public offline harness. A test wrapper must
  provide `reset`, `simulateAmbiguousOperationOnce` (for CREATE, UPDATE, and
  DELETE), `simulateUpdateNotAppliedOnce`,
  `simulateIndeterminateReconcileOnce`, and a connector implementation. The
  runner reports every check, including exact replay, identity isolation,
  malformed-output rejection, and reconciliation proof, instead of stopping at
  the first failure. The reference fake is deterministic and stores no
  provider state.

## Primary-file-provider protocol

Every authenticated request and response carries one value for
`x-s360-envelope`, `x-s360-key-id`, and `x-s360-signature`. The envelope header
is unpadded base64url of the exact JCS envelope. The signature is a raw 64-byte
Ed25519 signature, also unpadded base64url, over the direction-specific domain
prefix followed by those canonical bytes.

`verifySignedPrimaryFileProviderRequest` and its response counterpart parse the
canonical envelope, verify the signature and current validity window, and
require the received request method/path or response status plus the exact
transported body bytes. Request verification also proves that the signed
method, path, and operation select the same closed route. A signature-only
success is never returned for a stale or differently bound message. The lower
level canonical parsers remain available for diagnostics and reject duplicate
keys, invalid I-JSON, unknown or missing properties, and
noncanonical-but-equivalent JSON.

Provider object IDs are bounded opaque safe-ASCII values and must never be
interpreted as URLs or storage paths. A signed permanent-delete request is only
protocol intent: these validators grant no provider authority and do not
replace Simply360 authorization, legal-hold/export checks, migration-source
protection, quarantine/revalidation, immutable-version checks, routing, or
`File.simplyId` ownership. The Proof A conformance profile separately restricts
its disposable objects to `proof.*`; the generic protocol does not.

Regenerate or verify the deterministic artifacts with:

```bash
npm run generate:primary-file-provider-contract
npm --workspace @simply360/integration-sdk run check:file-provider-contract
```

The generator accepts `--reference-directory <contracts-directory>` to require
byte-for-byte parity with an independently implemented provider.

## License

Apache-2.0. See [LICENSE](./LICENSE) and [NOTICE](./NOTICE).
